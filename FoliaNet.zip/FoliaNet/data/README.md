# Data

FoliaNet trains on an ImageFolder-style dataset: a directory whose immediate
subfolders are class names containing images.

## PlantVillage (corn)

```bash
pip install kagglehub
python -m folianet.data.download
```

Then set `data.root` in `configs/default.yaml` to the folder that directly
contains the class subfolders (e.g. `Corn_(maize)___Common_rust_/`).

## Wheat

Classic PlantVillage has **corn but not wheat**. To detect wheat diseases, add a
wheat leaf disease dataset and name its class folders to match the keys in
`folianet/diseases.py` (e.g. `Wheat___Leaf_rust`), or add new entries there.
The data layer auto-includes any class folder whose name contains a keyword in
`data.crops`.

This directory is git-ignored — datasets are not committed.
