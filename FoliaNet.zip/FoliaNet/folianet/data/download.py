"""
Helper to obtain the PlantVillage dataset.

Easiest path: `kagglehub` (requires a free Kaggle account + token).
    pip install kagglehub
    python -m folianet.data.download

If that isn't available, follow the printed manual instructions. After download,
point `data.root` in configs/default.yaml at the folder that directly contains
the class subfolders.
"""

INSTRUCTIONS = """
Manual download:
  1. Get PlantVillage from Kaggle, e.g.:
       https://www.kaggle.com/datasets/abdallahalidev/plantvillage-dataset
       (or 'emmarex/plantdisease')
  2. Unzip it. Find the folder whose subfolders are class names like
     'Corn_(maize)___Common_rust_'.
  3. Set data.root in configs/default.yaml to that folder.

Note: classic PlantVillage has CORN classes but no WHEAT. For wheat, add a wheat
disease dataset (e.g. a Kaggle 'wheat leaf disease' set) whose class folders are
named to match the keys in folianet/diseases.py (or add new keys there).
"""


def main():
    try:
        import kagglehub
        path = kagglehub.dataset_download("abdallahalidev/plantvillage-dataset")
        print(f"Downloaded to: {path}")
        print("Set data.root in configs/default.yaml to the subfolder containing class dirs.")
    except Exception as e:
        print(f"Automatic download unavailable ({e}).")
        print(INSTRUCTIONS)


if __name__ == "__main__":
    main()
